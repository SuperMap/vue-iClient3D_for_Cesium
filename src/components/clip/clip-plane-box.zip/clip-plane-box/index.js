

import clipPlaneBox from './clip-plane-box.vue';

clipPlaneBox.install = function(app) {
  app.component(clipPlaneBox.name, clipPlaneBox);
};

export default clipPlaneBox;