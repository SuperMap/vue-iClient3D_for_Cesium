
// 引入依赖
import { watch, reactive, toRefs, onBeforeUnmount } from "vue";
import { initHandler, handlerDrawing, clearHandlerDrawing } from "../../../js/common/drawHandler.js"    //公共handler.js
import { Edit, clearEditHandler } from "../../../js/common/editHandler.js"   //编辑
import tool from '../../../js/tool/tool.js'        //提示等工具
import resource from '../../../js/local/lang.js'  //语言资源
import createTooltip from '../../../js/tool/tooltip2.js';
import { storeState } from '../../../js/store/store.js'   //简单局部状态管理

function clipPlaneAnalysis(props) {
    // 设置默认值数据
    let state = reactive({
        isEdit: false,//是否编辑
        isEditZ: false,
        lineVisible: true,//是否显示绘制线
        PlanePositions: []
    });

    // 传入props改变默认值
    if (props) {
        for (let key in props) {
            if (state.hasOwnProperty(key)) {
                state[key] = props[key]
            } else {
                tool.Message.errorMsg(resource.AttributeError + key);
            }
        }
    }

    // 初始化数据
    let layers;
    let planePositionObj  = {};
    let editEntity, s3mInstanceColc;
    let modelUrl = 'public/data/s3m/box.s3m';
    let modelEditor;

    /*
     ***平面分析模块***
    */
    //监听图层加载完成
    watch(() => storeState.changeLayers, val => {
        layers = viewer.scene.layers.layerQueue;
        for (let layer of layers) {
            layer.selectEnabled = false;
            // 设置被裁剪对象的颜色
            layer.clipLineColor = new Cesium.Color(1, 1, 1, 0);
        }
    });

    if (storeState.isViewer) {
        layers = viewer.scene.layers.layerQueue;
        s3mInstanceColc = new Cesium.S3MInstanceCollection(scene._context);
        viewer.scene.primitives.add(s3mInstanceColc);
        if (!window.tooltip) {
            window.tooltip = createTooltip(viewer._element);
        }
    }
    //viewer 初始化完成的监听
    watch(() => storeState.isViewer, val => {
        if (val) {
            layers = viewer.scene.layers.layerQueue;
            s3mInstanceColc = new Cesium.S3MInstanceCollection(scene._context);
            viewer.scene.primitives.add(s3mInstanceColc);
            if (!window.tooltip) {
                window.tooltip = createTooltip(viewer._element);
            }
        }
    })


    // 分析
    function clipPlaneStart(e) {
        e.preventDefault();
        tooltip.setVisible(false);
        tooltip.showAt(' <p>点击鼠标左键开始绘制直线</p><p>点击鼠标右键结束绘制</p>', '230px');
        if (!window.handlerPolygon) {
            initHandler("Polyline");
        }
        handlerDrawing("Polyline").then(
            res => {
                let handlerPolyline = window.handlerPolyline;
                handlerPolyline.polyline.show = false;
                window.polylineTransparent.show = false; //半透线隐藏
                handlerPolyline.deactivate();
                setPlanePositions(res.positions, res.result.object._positions)
                tooltip.setVisible(false);
            },
            (err) => {
                console.log(err);
            }
        );
        window.handlerPolyline.activate();
    };

    function setPlanePositions(linePositions, carPos) {
        let point1 = linePositions.slice(0, 3);
        let point2 = linePositions.slice(3, 6);
        let width = Cesium.Cartesian3.distance(carPos[0], carPos[1]);
        if (!width && width <= 0) width = 100;
        let point3 = point2.slice(0, 2).concat(point2[2] + width);
        let point4 = point1.slice(0, 2).concat(point1[2] + width);
        let points = [point1, point2, point3, point4];
        let catPoints = [];
        points.forEach((p) => {
            let cp = Cesium.Cartesian3.fromDegrees(p[0], p[1], p[2]);
            catPoints.push(cp)
        })
        let centerP = Cesium.BoundingSphere.fromPoints(catPoints).center;
        console.log(points, catPoints, centerP)
        planePositionObj = {
            lonlatPositions: points,
            cartPositions: catPoints,
            centerPositions: centerP
        }
        addsurface()
        clipPlaneUpdate()

    }
    let p1;
    let planeSurface ;
    function addsurface() {
        planeSurface =  viewer.entities.add({
            id: "polygon-symbol-gon-" + new Date().getTime(),
            polygon: {
                hierarchy: new Cesium.CallbackProperty(() => {
                    return {
                        positions: planePositionObj.cartPositions,
                        holes: []
                    }
                }, false),
                material: Cesium.Color.AQUA.withAlpha(0.2),
                perPositionHeight: true,
            },
        });

        addModel()
    }

    function addModel() {
        let getAngleAndRadian = tool.getAngleAndRadian(planePositionObj.cartPositions[0], planePositionObj.cartPositions[1]);
        let heading = getAngleAndRadian.radian;
        let id = "clip-model-" + new Date().getTime();
        s3mInstanceColc.add(modelUrl, {
            id: id,
            position: planePositionObj.centerPositions,
            hpr:new Cesium.HeadingPitchRoll(heading, 0, 0),
            // color:Cesium.Color.RED,
            scale: new Cesium.Cartesian3(0.2, 0.2, 0.2),
        });
        editEntity = s3mInstanceColc.getInstance(modelUrl, id);
        if (!modelEditor) addModelEditor(editEntity)
    }

    function addModelEditor(model) {
        modelEditor = new Cesium.ModelEditor({
            model: model,
            scene: viewer.scene,
            axesShow: {
                "translation": true,
                "rotation": false,
                "scale": false
            }
        });
        modelEditor.activate();
        modelEditor.changedEvt.addEventListener((param) => {
            let Cartesian3 = new Cesium.Cartesian3();
            Cesium.Matrix4.getTranslation(param.modelMatrix, Cartesian3);
            if (Cartesian3) {
               let subx = Cartesian3.x - planePositionObj.centerPositions.x;
               let suby = Cartesian3.y - planePositionObj.centerPositions.y;
               let subz = Cartesian3.z - planePositionObj.centerPositions.z;
               for(let i = 0 ;i < 4 ;i++){
                planePositionObj.cartPositions[i].x += subx;
                planePositionObj.cartPositions[i].y += suby;
                planePositionObj.cartPositions[i].z += subz;
               }
               planePositionObj.centerPositions = Cartesian3;
               clipPlaneUpdate()
            //    planeSurface.polygon.hierarchy = new Cesium.PolygonHierarchy(planePositionObj.cartPositions)  
            }
        })
    }


    // 更新
    function clipPlaneUpdate() {
        if(!planePositionObj.cartPositions) return
        for (let layer of layers) {
            // layer.clearCustomClipBox();
            layer.setCustomClipPlane(
                planePositionObj.cartPositions[0],
                planePositionObj.cartPositions[1],
                planePositionObj.cartPositions[2]
            );
        }
    };

    // 清除
    function clearClipPlane(e) {
        e.preventDefault();
        tooltip.setVisible(false);
        planePosition = [];
        if (!window.handlerPolygon) return;
        clearHandlerDrawing("Polygon");
        for (let layer of layers) {
            layer.clearCustomClipBox();
        }
    };

    // 监听

    watch(() => state.isEdit, val => {
        if (val && window.handlerPolygon) {
            Edit(planePosition, state.isEditZ, clipPlaneUpdate);
        } else {
            clearEditHandler("Polygon");
            if (window.handlerPolygon && window.handlerPolygon.polygon) {
                window.handlerPolygon.polygon.show = false;
            }
        }
    });
    watch(() => state.isEditZ, val => {
        if (window.editHandler) {
            window.editHandler.isEditZ = val;
        }
    });


    // 销毁
    onBeforeUnmount(() => {
        layers = undefined;
    })

    return {
        ...toRefs(state),
        clipPlaneStart,
        clearClipPlane,
    };
};

export default clipPlaneAnalysis

